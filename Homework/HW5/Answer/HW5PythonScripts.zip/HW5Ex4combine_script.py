#!/usr/bin/env python

# Following is based on the max_temperature_map.py script from Tom White's Hadoop: The Definitive Guide, 4th Edition.
# We can use this same map script for exercises 1 and 2 in the homework 5 assignment for the Spring 2016 Stat 480 course.

import sys

(last_key, mean_val, n_val) = (None, 0., 0)
for line in sys.stdin:
  (key, val) = line.strip().split("\t")
  if last_key and last_key != key:
    print "%s\t%s\t%s" % (last_key, mean_val, n_val)
    (last_key, mean_val, n_val) = (key, float(val), 1)
  else:
# for improved numerical stability, calculate mean value sequentially and make sure to use the fraction n/(n+1)
# to avoid multiplying out to the total, which might be very large
# while this should help stability, this may still suffer from truncation if there are a huge number of observations
# while our sample size is big here, the individual values have at most 3 digits so we should not have issues 
    (last_key, mean_val, n_val) = (key, (float(n_val)/(float(n_val)+1.))*mean_val + float(val)/(float(n_val)+1.), n_val+1)

if last_key:
  print "%s\t%s\t%s" % (last_key, mean_val, n_val)
