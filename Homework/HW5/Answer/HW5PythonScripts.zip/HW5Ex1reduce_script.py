#!/usr/bin/env python

# Following is based on the max_temperature_reduce.py script from Tom White's Hadoop: The Definitive Guide, 4th Edition.
# To get the min instead of the max, we replace max with min and initialize the min value as
# sys.maxint (largest machine integer) instead of -sys.maxint.
# In the print stage, temps are multiplied by .1 to return in degrees Celsius.

import sys

(last_key, min_val) = (None, sys.maxint)
for line in sys.stdin:
  (key, val) = line.strip().split("\t")
  if last_key and last_key != key:
    print "%s\t%s" % (last_key, .1*float(min_val))
    (last_key, min_val) = (key, int(val))
  else:
    (last_key, min_val) = (key, min(min_val, int(val)))

if last_key:
  print "%s\t%s" % (last_key, .1*float(min_val))
