#!/usr/bin/env python
# This is based on the map script from Chapter 2 of Hadoop: The Definitive Guide, 4th Edition by Tom White.
# This script will do the mapping we need for Exercises 1, 2 and 4 of homework 5. The only change from the
# code provided with the text book is the fields needed to extract the month measurements.

import re
import sys

for line in sys.stdin:
  val = line.strip()
  (year, temp, q) = (val[19:21], val[87:92], val[92:93])
  if (temp != "+9999" and re.match("[01459]", q)):
    print "%s\t%s" % (year, temp)
