#!/usr/bin/env python

# Following is based on the max_temperature_reduce.py script from Tom White's Hadoop: The Definitive Guide, 4th Edition.
# It has been modified to calculate means instead of maxes.
# Means are calculated as rolling means using the formula xbar_n1 = (n/(n+1))*xbar_n + x_n1/(n+1).
# Final conversion to degrees Celsius is left for the final step to reduce the number of multiplications performed.

import sys

(last_key, mean_val, n_val) = (None, 0., 0)
for line in sys.stdin:
  (key, tval, newn_val) = line.strip().split("\t")
  if last_key and last_key != key:
    print "%s\t%s" % (last_key, .1*float(mean_val))
    (last_key, mean_val, n_val) = (key, float(tval), int(newn_val))
  else:
    (last_key, mean_val, n_val) = (key, (float(n_val)/(float(n_val) + float(newn_val)))*mean_val + (float(newn_val)/(float(n_val) + float(newn_val)))*float(tval) , n_val + int(newn_val))

if last_key:
  print "%s\t%s" % (last_key, .1*float(mean_val))

