#!/usr/bin/env python

# Following is based on the max_temperature_reduce.py script from Tom White's Hadoop: The Definitive Guide, 4th Edition.
# To get count, min, and max, we combine the previous steps making sure to only go through the data once, 
# so the count, min, and max values must be updated at each step.

import sys

(last_key, n_val, min_val, max_val) = (None, 0, sys.maxint, -sys.maxint)
for line in sys.stdin:
  (key, val) = line.strip().split("\t")
  if last_key and last_key != key:
    print "%s\t%s\t%s\t%s" % (last_key, n_val, .18*float(min_val)+32.0, .18*float(max_val)+32.0)
    (last_key, n_val, min_val, max_val) = (key, 1, int(val), int(val))
  else:
    (last_key, n_val, min_val, max_val) = (key, n_val+1, min(min_val, int(val)), max(max_val, int(val)))

if last_key:
  print "%s\t%s\t%s\t%s" % (last_key,n_val, .18*float(min_val)+32.0, .18*float(max_val)+32.0)
