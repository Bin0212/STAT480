#!/usr/bin/env python
# Based on map script from Chapter 2 of Hadoop The Definitive Guide by Tom White
# Below, we only get the year, temp, and quality code values. The reducer will count up the 
# valid ones.

import re
import sys

for line in sys.stdin:
  (tct, validqct) = (0, 0)
  val = line.strip()
  (year, temp, q) = (val[19:21], val[87:92], val[92:93])
  if (temp != "+9999"):
	tct = 1

  if re.match("[01459]", q):
	validqct = 1
  
  if tct+validqct > 0:
    	print "%s\t%s\t%s" % (year, tct, validqct)
