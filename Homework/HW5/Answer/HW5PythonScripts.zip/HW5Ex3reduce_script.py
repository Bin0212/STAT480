#!/usr/bin/env python

# Following is based on the max_temperature_reduce.py script from Tom White's Hadoop: The Definitive Guide, 4th Edition.
# The mapper has removed bad observations and returned 0 and 1 values inticating invalid|valid temp and 
# invalid|valid quality code, so we only need to add up those values.

import sys

(last_key, t_ct, vq_ct) = (None, 0, 0)
for line in sys.stdin:
  (key, tval, vqval) = line.strip().split("\t")
  if last_key and last_key != key:
    print "%s\t%s\t%s" % (last_key, t_ct, vq_ct)
    (last_key, t_ct, vq_ct) = (key, int(tval), int(vqval))
  else:
    (last_key, t_ct, vq_ct) = (key, t_ct + int(tval), vq_ct + int(vqval))

if last_key:
  print "%s\t%s\t%s" % (last_key, t_ct, vq_ct)
